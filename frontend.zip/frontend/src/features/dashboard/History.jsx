import React from 'react'
import Navbar from '../../components/Navbar'

const History = () => {
  return (
    <>
      <Navbar />
      <main className="flex flex-col justify-start gap-0 mt-8">
        <h2 className="text-center text-2xl font-semibold">Transaction History</h2>

        <table className="mt-5 w-4/5 mx-auto border-collapse bg-white shadow-md rounded-md">
          <thead>
            <tr>
              <th className="p-3 text-center bg-red-600 text-white">Customer ID</th>
              <th className="p-3 text-center bg-red-600 text-white">Payment Date</th>
              <th className="p-3 text-center bg-red-600 text-white">Amount Paid</th>
              <th className="p-3 text-center bg-red-600 text-white">Payment Status</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="p-3 text-center">U123456789</td>
              <td className="p-3 text-center">2025-04-01</td>
              <td className="p-3 text-center">5000</td>
              <td className="p-3 text-center text-green-500 font-bold">On Time</td>
            </tr>
            <tr>
              <td className="p-3 text-center">U123456789</td>
              <td className="p-3 text-center">2025-03-03</td>
              <td className="p-3 text-center">7000</td>
              <td className="p-3 text-center text-red-500 font-bold">Late</td>
            </tr>
            <tr>
              <td className="p-3 text-center">U123456789</td>
              <td className="p-3 text-center">2025-02-05</td>
              <td className="p-3 text-center">4000</td>
              <td className="p-3 text-center text-green-500 font-bold">On Time</td>
            </tr>
            <tr>
              <td className="p-3 text-center">U123456789</td>
              <td className="p-3 text-center">2025-01-07</td>
              <td className="p-3 text-center">9000</td>
              <td className="p-3 text-center text-red-500 font-bold">Late</td>
            </tr>
          </tbody>
        </table>
      </main>
    </>
  )
}

export default History
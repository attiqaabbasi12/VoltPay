import React, { useState } from 'react';

const Complaint = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    consumer_id: '',
    complaint_type: '',
    message: '',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitted:', formData);
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      consumer_id: '',
      complaint_type: '',
      message: '',
    });
  };

  return (
    <div className='flex justify-center bg-gray-200 items-center h-[100vh]'>
   <div className="w-[35%] h-[95vh] px-8 py-2 text-center shadow-2xl rounded-md flex flex-col justify-center bg-white">
      <h2 className="text-[30px] text-red-600 font-semibold mb-4">Complaint Form</h2>
      <form className="flex flex-col items-center text-left w-full">
        {/* Full Name */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="name">Full Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            required
            className="h-[35px] rounded px-3 border border-black focus:outline-none focus:border-red-600"
          />
        </div>

        {/* Email Address */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="email">Email Address:</label>
          <input
            type="email"
            id="email"
            name="email"
            required
            className="h-[35px] rounded px-3 border border-black focus:outline-none focus:border-red-600"
          />
        </div>

        {/* Phone Number */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="phone">Phone Number:</label>
          <input
            type="text"
            id="phone"
            name="phone"
            required
            className="h-[35px] rounded px-3 border border-black focus:outline-none focus:border-red-600"
          />
        </div>

        {/* Consumer ID */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="consumer_id">Consumer ID:</label>
          <input
            type="text"
            id="consumer_id"
            name="consumer_id"
            required
            className="h-[35px] rounded px-3 border border-black focus:outline-none focus:border-red-600"
          />
        </div>

        {/* Complaint Type */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="complaint_type">Complaint Type:</label>
          <select
            id="complaint_type"
            name="complaint_type"
            required
            className="h-[35px] rounded px-3 border border-black focus:outline-none focus:border-red-600"
          >
            <option value="">Select Complaint Type</option>
            <option value="Payment Issue">Payment Issue</option>
            <option value="Incorrect Bill">Incorrect Bill</option>
            <option value="Other">Other</option>
          </select>
        </div>

        {/* Complaint Details */}
        <div className="flex flex-col w-[85%] mt-3">
          <label htmlFor="message">Complaint Details:</label>
          <textarea
            id="message"
            name="message"
            rows="3"
            className="h-[70px] rounded px-3 py-2 border border-black focus:outline-none focus:border-red-600"
          ></textarea>
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          className="mt-5 px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700 transition-colors"
        >
          Submit Complaint
        </button>
      </form>
    </div>
    </div>
  );
};

export default Complaint;

import Navbar from '../../components/Navbar';
import React, { useState, useEffect, useRef } from 'react';
import Chart from 'chart.js/auto';

const Dashboard = () => {
  const [billData, setBillData] = useState(null);
  const [customerId, setCustomerId] = useState('');
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  // Dummy fetch function to simulate bill data
  const fetchBillData = () => {
    if (!customerId) return alert("Please enter a customer ID.");

    // Simulated bill data
    const dummyData = {
      name: "Ali Khan",
      month: "May",
      amount: "Rs. 3,200",
      dueDate: "25 May, 2025",
      status: "Unpaid",
    };

    setBillData(dummyData);
  };

  useEffect(() => {
    if (!chartRef.current) {
      console.error("Canvas ref not found");
      return;
    }

    const ctx = chartRef.current.getContext('2d');

    // Destroy previous chart instance if it exists
    if (chartInstance.current) {
      console.log("Destroying previous chart instance");
      chartInstance.current.destroy();
      chartInstance.current = null;
    }

    // Create new chart instance
    chartInstance.current = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: ['Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
        datasets: [
          {
            label: 'Monthly Usage (kWh)',
            data: [410, 400, 390, 330, 300, 250, 270, 370],
            backgroundColor: 'rgba(252, 61, 103, 0.91)',
            borderColor: 'rgba(255, 99, 132, 1)',
            borderWidth: 1,
          },
        ],
      },
      options: {
        responsive: true,
        plugins: {
          title: {
            display: true,
            text: 'Electricity Usage per Month',
            font: {
              size: 18,
              weight: 'bold',
            },
          },
          legend: {
            display: false,
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 50,
            },
          },
        },
      },
    });

    return () => {
      if (chartInstance.current) {
        console.log("Destroying chart instance on unmount");
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, []);

  return (
    <>
      <Navbar />
      <main className="w-full h-[540px] flex justify-around items-center px-12 bg-stone-200">
        {/* Bill Inquiry Form */}
        <div className="inquiry border rounded-lg p-6 shadow-2xl bg-white max-w-md">
          <h2 className="text-center font-bold text-xl">Inquire Bill</h2>
          <form onSubmit={(e) => e.preventDefault()}>
            <div className="input-field mt-5 flex flex-col mb-4">
              <label htmlFor="customer-id" className="mb-1 font-semibold">
                Customer ID:
              </label>
              <input
                type="number"
                id="customer-id"
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="p-2 rounded-md border-2 border-gray-700 focus:outline-none focus:border-red-500"
                placeholder="Enter customer ID"
              />
            </div>
            <input
              type="button"
              onClick={fetchBillData}
              value="Inquire"
              className="w-full p-2 text-white bg-red-600 rounded-md cursor-pointer text-lg hover:bg-red-700 transition"
            />
          </form>

          {/* Display bill data if available */}
          {billData && (
            <div className="bill-data mt-7 space-y-1 text-gray-700">
              <p><strong>Customer:</strong> {billData.name}</p>
              <p><strong>Billing Month:</strong> {billData.month}</p>
              <p><strong>Amount:</strong> {billData.amount}</p>
              <p><strong>Due Date:</strong> {billData.dueDate}</p>
              <p><strong>Status:</strong> {billData.status}</p>
              <div className="mt-3 bg-red-600 text-center p-2 rounded-md cursor-pointer hover:bg-red-700 transition">
                <a href="/dashboard/payment" className="text-white no-underline">Pay</a>
              </div>
            </div>
          )}
        </div>

        {/* Usage Chart */}
        <div>
          <canvas
            ref={chartRef}
            width={600}   // Explicit width
            height={400}  // Explicit height
            className="bg-white p-4 rounded-md shadow-xl"
            aria-label="Electricity usage bar chart"
            role="img"
          ></canvas>
        </div>
      </main>
    </>
  );
};

export default Dashboard;

import Navbar from '../../components/Navbar'
import React, { useState } from 'react';

const Payment = () => {
   const [loading, setLoading] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setLoading(true);
    setPaymentSuccess(false);

    setTimeout(() => {
      setLoading(false);
      setPaymentSuccess(true);
    }, 2000);
  };

  return (
    <div className='bg-stone-200 h-[100vh]'>
      <Navbar />
      <div className="payment-form mt-8 bg-white p-8 rounded-lg shadow-md w-96 mx-auto">
        <h2 className="text-center text-2xl font-semibold">Payment Form</h2>
        <form id="paymentForm" onSubmit={handleSubmit}>
          <input
            type="text"
            id="customerID"
            placeholder="Enter Customer ID"
            required
            className="w-full mt-4 p-2 border rounded-md border-gray-400"
          />
          <input
            type="number"
            id="amount"
            placeholder="Enter Amount"
            required
            className="w-full mt-4 p-2 border rounded-md border-gray-400"
          />
          <select
            id="paymentMethod"
            required
            className="w-full mt-4 p-2 border rounded-md border-gray-400"
          >
            <option value="">Select Payment Method</option>
            <option value="EasyPaisa">EasyPaisa</option>
            <option value="JazzCash">JazzCash</option>
            <option value="BankTransfer">Bank Transfer</option>
          </select>
          <input
            type="text"
            id="accountNumber"
            placeholder="Enter Account Number"
            required
            className="w-full mt-4 p-2 border rounded-md border-gray-400"
          />
          <button
            type="submit"
            className="w-full mt-6 p-2 bg-red-600 text-white rounded-md cursor-pointer"
          >
            Proceed Now
          </button>
          {loading && (
            <div className="loader mt-4 mx-auto border-t-4 border-t-red-600 border-4 border-gray-300 rounded-full w-8 h-8 animate-spin"></div>
          )}
          {paymentSuccess && (
            <div className="success-message mt-4 text-red-600 font-bold">
              Payment Successful!
            </div>
          )}
        </form>
      </div>
    </div>
  )
}

export default Payment
import React from "react";
import { useNavigate } from "react-router-dom";

const Login = () => {
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault(); // Prevent form reload
    navigate("/dashboard"); // Navigate to dashboard
  };

  return (
    <div className="w-full h-screen flex">
      {/* Login Form Section */}
      <div className="w-1/2 flex items-center justify-center">
        <form className="w-[320px]" onSubmit={handleLogin}>
          <h1 className="text-center text-red-600 font-semibold text-3xl mb-8">Sign In</h1>

          <div className="relative mb-5">
            <i className="fas fa-user absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="email"
              name="email"
              placeholder="Email"
              required
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="relative mb-5">
            <i className="fas fa-lock absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="password"
              name="password"
              placeholder="Password"
              required
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="mb-4">
            <button
              type="submit"
              className="block w-full text-center py-3 bg-red-600 text-white rounded-md font-medium hover:bg-red-700 transition"
            >
              Sign In
            </button>
          </div>
        </form>
      </div>

      {/* Right Panel Section */}
      <div className="w-1/2 bg-red-600 text-white flex flex-col justify-center px-20">
        <h1 className="text-[70px] leading-[70px] font-bold mb-2">New Here?</h1>
        <p className="text-[20px] w-3/4">
          Create an account and start your energy journey with us! Pay your electricity bills online in seconds, anytime, anywhere!
        </p>
        <button
          className="w-1/3 mt-5 px-4 py-2 bg-white text-red-600 font-bold rounded-md text-lg hover:bg-white/90 transition"
          onClick={() => navigate("/signup")}
        >
          Register Now!
        </button>
      </div>
    </div>
  );
};

export default Login;

import React, { useState } from "react";

const SignUp = () => {
  

  return (
    <div className="w-full h-screen flex">
      {/* Left Panel */}
      <div className="w-1/2 bg-red-600 text-white flex flex-col justify-center px-20">
        <h1 className="text-[80px] leading-[85px] font-bold mb-2">Already part of our power family?</h1>
        <p className="text-[20px]">Login and stay in charge of your energy!</p>
        <button
          className="w-1/4 mt-5 px-4 py-2 bg-white text-red-600 rounded-md font-bold text-lg hover:bg-white/90 transition"
          onClick={() => window.location.href = "/login"}
        >
          Sign In
        </button>
      </div>

      {/* Signup Form */}
      <div className="w-1/2 flex items-center justify-center">
        <form className="w-[320px]" >
          <h1 className="text-center text-red-600 font-semibold text-3xl mb-8">Sign Up</h1>

          <div className="relative mb-5">
            <i className="fas fa-envelope absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="email"
              name="email"
              placeholder="Email"
              required
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="relative mb-5">
            <i className="fas fa-lock absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="password"
              name="password"
              placeholder="Password"
              required
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="relative mb-5">
            <i className="fas fa-lock absolute top-1/2 left-4 -translate-y-1/2 text-gray-600"></i>
            <input
              type="password"
              name="confirm_password"
              placeholder="Confirm Password"
              required
              className="w-full pl-10 pr-4 py-3 border-2 border-gray-300 rounded-md bg-gray-100 focus:outline-none focus:border-red-600 focus:bg-white"
            />
          </div>

          <div className="mb-4">
            <button
              type="submit"
              className="w-full py-3 bg-red-600 text-white rounded-md font-medium hover:bg-red-700 transition"
            >
              Register
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default SignUp;

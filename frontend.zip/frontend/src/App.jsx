import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

// Landing page
import Landing from "./pages/LandingPage";

// Auth pages
import Login from "./features/auth/Login";
import SignUp from "./features/auth/Signup";

// Dashboard pages
import DashboardHome from "./features/dashboard/Dashboard";
import ComplaintForm from "./features/dashboard/Complaint";
import Payment from "./features/dashboard/Payment";
import History from "./features/dashboard/History";

const App = () => {
  return (
    <Router>
      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />

        {/* Dashboard Routes */}
        <Route path="/dashboard" element={<DashboardHome />} />
        <Route path="/dashboard/complaint" element={<ComplaintForm />} />
        <Route path="/dashboard/payment" element={<Payment />} />
        <Route path="/dashboard/history" element={<History />} />
      </Routes>
    </Router>
  );
};

export default App;
